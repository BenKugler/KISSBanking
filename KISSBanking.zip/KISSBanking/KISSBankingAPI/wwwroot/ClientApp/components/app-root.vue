<template>
  <div id="app" class="container-fluid">
    <router-view></router-view>
  </div>
</template>
<script>

  export default {
    components: {
    },

    data() {
      return {}
    }
  }
</script>
<style>
</style>
